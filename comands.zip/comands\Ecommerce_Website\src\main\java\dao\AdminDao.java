package dao;

import model.Product;
import model.User;
import utils.DBUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminDao {

    public static class ImageData {
        private final byte[] data;
        private final String contentType;
        public ImageData(byte[] data, String contentType) {
            this.data = data;
            this.contentType = contentType;
        }
        public byte[] getData() { return data; }
        public String getContentType() { return contentType; }
    }

    // ------------------ PRODUCTS ------------------

    public List<Product> getAllProducts() throws SQLException {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT TOP (200) p.product_id, p.product_name, p.category_id, " +
                "c.category_name, p.description, p.price, p.stock " +
                "FROM Ecommerce_Website.M_S_DATAS p " +
                "LEFT JOIN Ecommerce_Website.M_S_CATEGORY c ON p.category_id = c.category_id " +
                "ORDER BY p.product_id";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Product p = new Product();
                p.setProductId(rs.getInt("product_id"));
                p.setProductName(rs.getString("product_name"));
                p.setCategoryId(rs.getInt("category_id"));
                p.setDescription(rs.getString("description"));
                p.setPrice(rs.getDouble("price"));
                p.setStock(rs.getInt("stock"));

                String cat = rs.getString("category_name");
                if (cat != null) p.setCategoryname(cat);

                // Do NOT set image bytes here (keep JSON small)
                list.add(p);
            }
        }

        return list;
    }

    public boolean addProduct(Product p) throws SQLException {
        String sql = "INSERT INTO Ecommerce_Website.M_S_DATAS (category_id, product_name, description, price, stock, image) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, p.getCategoryId());
            ps.setString(2, p.getProductName());
            ps.setString(3, p.getDescription());
            ps.setDouble(4, p.getPrice());
            ps.setInt(5, p.getStock());

            if (p.getImageData() != null) {
                ps.setBytes(6, p.getImageData());
            } else {
                ps.setNull(6, Types.VARBINARY);
            }

            return ps.executeUpdate() > 0;
        }
    }

    public boolean updateProduct(Product p) throws SQLException {
        boolean hasImage = p.getImageData() != null;
        String sql;
        if (hasImage) {
            sql = "UPDATE Ecommerce_Website.M_S_DATAS SET category_id=?, product_name=?, description=?, price=?, stock=?, image=? WHERE product_id=?";
        } else {
            sql = "UPDATE Ecommerce_Website.M_S_DATAS SET category_id=?, product_name=?, description=?, price=?, stock=? WHERE product_id=?";
        }

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, p.getCategoryId());
            ps.setString(2, p.getProductName());
            ps.setString(3, p.getDescription());
            ps.setDouble(4, p.getPrice());
            ps.setInt(5, p.getStock());

            if (hasImage) {
                ps.setBytes(6, p.getImageData());
                ps.setInt(7, p.getProductId());
            } else {
                ps.setInt(6, p.getProductId());
            }

            return ps.executeUpdate() > 0;
        }
    }

    public boolean deleteProduct(int productId) throws SQLException {
        String sql = "DELETE FROM Ecommerce_Website.M_S_DATAS WHERE product_id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, productId);
            return ps.executeUpdate() > 0;
        }
    }

    // ------------------ USERS ------------------

    public List<User> getAllUsers() throws SQLException {
        List<User> list = new ArrayList<>();
        String sql = "SELECT user_id, fullname, email, phone, is_active as status FROM Ecommerce_Website.M_S_USER";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                User u = new User();
                u.setId(rs.getInt("user_id"));
                u.setName(rs.getString("fullname"));
                u.setEmail(rs.getString("email"));
                u.setMobile(rs.getString("phone"));
                u.setStatus(rs.getInt("status"));
                list.add(u);
            }
        }
        return list;
    }

    public boolean updateUserStatus(int userId, boolean active) throws SQLException {
        String sql = "UPDATE Ecommerce_Website.M_S_USER SET is_active = ? WHERE user_id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, active ? 1 : 0);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean deleteUser(int userId) throws SQLException {
        return updateUserStatus(userId, false);
    }

    /**
     * changePassword: checks current password then updates.
     * Note: this compares plain-text. For production use hashed passwords.
     */
    public boolean changePassword(int userId, String currentPwd, String newPwd) throws SQLException {
        String checkSql = "SELECT password FROM Ecommerce_Website.M_S_USER WHERE user_id = ?";
        String updateSql = "UPDATE Ecommerce_Website.M_S_USER SET password = ? WHERE user_id = ?";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement checkPs = conn.prepareStatement(checkSql)) {

            checkPs.setInt(1, userId);
            try (ResultSet rs = checkPs.executeQuery()) {
                if (rs.next()) {
                    String existing = rs.getString("password");
                    if (!existing.equals(currentPwd)) return false; // mismatch
                } else {
                    return false; // user not found
                }
            }

            try (PreparedStatement upd = conn.prepareStatement(updateSql)) {
                upd.setString(1, newPwd);
                upd.setInt(2, userId);
                return upd.executeUpdate() > 0;
            }
        }
    }

    // ------------------ CATEGORIES ------------------

    public List<Map<String, Object>> getAllCategories() throws SQLException {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT category_id, category_name, description FROM Ecommerce_Website.M_S_CATEGORY";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("category_id", rs.getInt("category_id"));
                row.put("category_name", rs.getString("category_name"));
                row.put("description", rs.getString("description"));
                list.add(row);
            }
        }
        return list;
    }

    public boolean addCategory(String name, String description) throws SQLException {
        String sql = "INSERT INTO Ecommerce_Website.M_S_CATEGORY (category_name, description) VALUES (?, ?)";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, description);
            return ps.executeUpdate() > 0;
        }
    }

    // ------------------ DISCOUNTS ------------------

    public List<Map<String, Object>> getAllDiscounts() throws SQLException {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT d.discount_id, d.product_id, d.discount_percent, d.start_date, d.end_date, " +
                     "p.product_name, p.price, d.createdat " +
                     "FROM Ecommerce_Website.M_S_PRODUCT_DISCOUNTS d " +
                     "LEFT JOIN Ecommerce_Website.M_S_DATAS p ON d.product_id = p.product_id " +
                     "ORDER BY d.discount_id DESC";

        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("discount_id", rs.getInt("discount_id"));
                row.put("product_id", rs.getInt("product_id"));
                row.put("product_name", rs.getString("product_name"));
                row.put("discount_percent", rs.getDouble("discount_percent"));
                row.put("price", rs.getDouble("price"));
                row.put("start_date", rs.getTimestamp("start_date"));
                row.put("end_date", rs.getTimestamp("end_date"));
                row.put("createdat", rs.getTimestamp("createdat"));
                list.add(row);
            }
        }
        return list;
    }

    public boolean addDiscount(int productId, double discountPercent, Timestamp startDate, Timestamp endDate) throws SQLException {
        String sql = "INSERT INTO Ecommerce_Website.M_S_PRODUCT_DISCOUNTS (product_id, discount_percent, start_date, end_date) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, productId);
            ps.setDouble(2, discountPercent);
            if (startDate != null) {
                ps.setTimestamp(3, startDate);
            } else {
                ps.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            }
            if (endDate != null) {
                ps.setTimestamp(4, endDate);
            } else {
                ps.setNull(4, Types.TIMESTAMP);
            }

            return ps.executeUpdate() > 0;
        }
    }

    public boolean updateDiscount(int discountId, double discountPercent, Timestamp startDate, Timestamp endDate) throws SQLException {
        String sql = "UPDATE Ecommerce_Website.M_S_PRODUCT_DISCOUNTS SET discount_percent=?, start_date=?, end_date=? WHERE discount_id=?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, discountPercent);
            if (startDate != null) {
                ps.setTimestamp(2, startDate);
            } else {
                ps.setNull(2, Types.TIMESTAMP);
            }
            if (endDate != null) {
                ps.setTimestamp(3, endDate);
            } else {
                ps.setNull(3, Types.TIMESTAMP);
            }
            ps.setInt(4, discountId);

            return ps.executeUpdate() > 0;
        }
    }

    public boolean deleteDiscount(int discountId) throws SQLException {
        String sql = "DELETE FROM Ecommerce_Website.M_S_PRODUCT_DISCOUNTS WHERE discount_id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, discountId);
            return ps.executeUpdate() > 0;
        }
    }

    // ------------------ IMAGE HELPERS ------------------

    /**
     * Try primary image from M_S_PRODUCT_IMAGES (by productId), if none found, fallback to image column in M_S_DATAS.
     */
    public ImageData getProductImage(int productId) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();

            // First try M_S_PRODUCT_IMAGES (primary image if exists)
            String sql = "SELECT TOP 1 image_data, content_type FROM Ecommerce_Website.M_S_PRODUCT_IMAGES WHERE product_id = ? ORDER BY is_primary DESC, id ASC";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, productId);
            rs = ps.executeQuery();
            if (rs.next()) {
                byte[] data = rs.getBytes("image_data");
                String ct = null;
                try { ct = rs.getString("content_type"); } catch (SQLException ignore) {}
                if (data != null && data.length > 0) {
                    return new ImageData(data, ct);
                }
            }
            // cleanup
            try { rs.close(); } catch (Exception ignored) {}
            try { ps.close(); } catch (Exception ignored) {}

            // Fallback to M_S_DATAS.image
            sql = "SELECT image FROM Ecommerce_Website.M_S_DATAS WHERE product_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, productId);
            rs = ps.executeQuery();
            if (rs.next()) {
                byte[] data = rs.getBytes("image");
                if (data != null && data.length > 0) {
                    // content type may not be stored; return null for contentType (servlet can detect)
                    return new ImageData(data, null);
                }
            }
            return null;
        } finally {
            if (rs != null) try { rs.close(); } catch (SQLException ignored) {}
            if (ps != null) try { ps.close(); } catch (SQLException ignored) {}
            if (conn != null) try { conn.close(); } catch (SQLException ignored) {}
        }
    }

    /**
     * Fetch image by its image record id (M_S_PRODUCT_IMAGES.id)
     */
    public ImageData getProductImageByImgId(int imgId) throws SQLException {
        String sql = "SELECT image_data, content_type FROM Ecommerce_Website.M_S_PRODUCT_IMAGES WHERE id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, imgId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    byte[] data = rs.getBytes("image_data");
                    String ct = null;
                    try { ct = rs.getString("content_type"); } catch (SQLException ignore) {}
                    return new ImageData(data, ct);
                }
            }
        }
        return null;
    }
}
