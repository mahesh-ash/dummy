package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import model.CartItem;
import utils.DBUtils;

public class CartDao  {

    public CartDao() {
    	
    }
    
    public void addToCart(int userId, int productId, int qty) throws SQLException {
        String select = "SELECT cart_id, quantity FROM Ecommerce_Websites.D_D_CART WHERE user_id=? AND product_id=?";
        String insert = "INSERT INTO Ecommerce_Websites.D_D_CART (user_id, product_id, quantity) VALUES (?,?,?)";
        String update = "UPDATE Ecommerce_Websites.D_D_CART SET quantity = ?, updatedat = GETDATE() WHERE cart_id = ?";

        Connection conn = null;
        PreparedStatement psSelect = null;
        ResultSet rs = null;
        PreparedStatement psUpdate = null;
        PreparedStatement psInsert = null;

        try {
            conn = DBUtils.getConnection();
            psSelect = conn.prepareStatement(select);
            psSelect.setInt(1, userId);
            psSelect.setInt(2, productId);
            rs = psSelect.executeQuery();

            if (rs.next()) {
                int cartId = rs.getInt("cart_id");
                int existing = rs.getInt("quantity");
                psUpdate = conn.prepareStatement(update);
                psUpdate.setInt(1, existing + qty);
                psUpdate.setInt(2, cartId);
                psUpdate.executeUpdate();
                return;
            }

            psInsert = conn.prepareStatement(insert);
            psInsert.setInt(1, userId);
            psInsert.setInt(2, productId);
            psInsert.setInt(3, qty);
            psInsert.executeUpdate();
        } finally {
            if (rs != null) {
                try { 
                	rs.close();
                    } catch (SQLException e) {
                    	e.printStackTrace();
                    }
            }
            if (psSelect != null) {
                try { 
                	psSelect.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
            if (psUpdate != null) {
                try { 
                	psUpdate.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
            if (psInsert != null) {
                try { 
                	psInsert.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
            if (conn != null) {
                try {
                	conn.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
        }
    }


    public void updateQuantity(int userId, int productId, int qty) throws SQLException {
        String update = "UPDATE Ecommerce_Websites.D_D_CART SET quantity = ?, updatedat = GETDATE() WHERE user_id=? AND product_id=?";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBUtils.getConnection();
            ps = conn.prepareStatement(update);
            ps.setInt(1, qty);
            ps.setInt(2, userId);
            ps.setInt(3, productId);
            ps.executeUpdate();
        } finally {
            if (ps != null) {
                try { 
                	ps.close();
                	} catch (SQLException e) {
                		e.getMessage();
                	}
            }
            if (conn != null) {
                try { 
                	conn.close();
                	} catch (SQLException e) {
                		e.getMessage();
                	}
            }
        }
    }


    public void removeFromCart(int userId, int productId) throws SQLException {
        String del = "DELETE FROM Ecommerce_Websites.D_D_CART WHERE user_id=? AND product_id=?";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBUtils.getConnection();
            ps = conn.prepareStatement(del);
            ps.setInt(1, userId);
            ps.setInt(2, productId);
            ps.executeUpdate();
        } finally {
            if (ps != null) {
                try {
                	ps.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
            if (conn != null) {
                try { 
                	conn.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
        }
    }

    public void removeItemsFromCart(int userId, List<Integer> productIds) throws SQLException {
        if (productIds == null || productIds.isEmpty()) return;

        String placeholders = String.join(",", Collections.nCopies(productIds.size(), "?"));
        String sql = "DELETE FROM Ecommerce_Websites.D_D_CART WHERE user_id = ? AND product_id IN (" + placeholders + ")";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            int idx = 2;
            for (Integer pid : productIds) {
                ps.setInt(idx++, pid);
            }
            ps.executeUpdate();
        } finally {
            if (ps != null) {
                try { 
                	ps.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
            if (conn != null) {
                try {
                	conn.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
        }
    }

 
    public List<CartItem> getCartItems(int userId) throws SQLException {
        List<CartItem> list = new ArrayList<>();
        String sql = "SELECT c.product_id, c.quantity, p.product_name, p.price, p.image " +
                     "FROM Ecommerce_Website.D_D_CART c LEFT JOIN Ecommerce_Websites.M_S_DATAS p ON c.product_id = p.product_id " +
                     "WHERE c.user_id = ? ";

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            rs = ps.executeQuery();

            while (rs.next()) {
                int pid = rs.getInt("product_id");
                int qty = rs.getInt("quantity");
                String name = rs.getString("product_name");
                double price = rs.getDouble("price");
                String image = rs.getString("image");
                list.add(new CartItem(pid, name, price, image, qty));
            }
        } finally {
            if (rs != null) {
                try { 
                	rs.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
            if (ps != null) {
                try { 
                	ps.close(); 
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
            if (conn != null) {
                try { 
                	conn.close(); 
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
        }

        return list;
    }

    public void clearCart(int userId) throws SQLException {
        String del = "DELETE FROM Ecommerce_Websites.D_D_CART WHERE user_id=?";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBUtils.getConnection();
            ps = conn.prepareStatement(del);
            ps.setInt(1, userId);
            ps.executeUpdate();
        } finally {
            if (ps != null) {
                try { 
                	ps.close(); 
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
            if (conn != null) {
                try { 
                	conn.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
        }
    }

    public void reorderItems(int userId, int orderId) throws SQLException {
        String itemsSql = "SELECT product_id, quantity FROM Ecommerce_Websites.D_D_ORDERLOGS WHERE order_id = ?";
        String addToCartSql = "MERGE INTO Ecommerce_Websites.D_D_CART AS target " +
                              "USING (VALUES (?, ?, ?)) AS source (user_id, product_id, quantity) " +
                              "ON target.user_id = source.user_id AND target.product_id = source.product_id " +
                              "WHEN MATCHED THEN UPDATE SET target.quantity = target.quantity + source.quantity " +
                              "WHEN NOT MATCHED THEN INSERT (user_id, product_id, quantity) VALUES (source.user_id, source.product_id, source.quantity) ;";

        Connection conn = null;
        PreparedStatement itemsPs = null;
        ResultSet rs = null;
        PreparedStatement addToCartPs = null;

        try {
            conn = DBUtils.getConnection();
            conn.setAutoCommit(false);

            itemsPs = conn.prepareStatement(itemsSql);
            addToCartPs = conn.prepareStatement(addToCartSql);

            itemsPs.setInt(1, orderId);
            rs = itemsPs.executeQuery();

            while (rs.next()) {
                int productId = rs.getInt("product_id");
                int quantity = rs.getInt("quantity");
                addToCartPs.setInt(1, userId);
                addToCartPs.setInt(2, productId);
                addToCartPs.setInt(3, quantity);
                addToCartPs.executeUpdate();
            }

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            throw e;
        } finally {
            if (rs != null) {
                try {
                	rs.close(); 
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
            if (itemsPs != null) {
                try { 
                	itemsPs.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
            if (addToCartPs != null) {
                try { 
                	addToCartPs.close(); 
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
            if (conn != null) {
                try { 
                	conn.setAutoCommit(true); 
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
                try { 
                	conn.close();
                	} catch (SQLException e) {
                		e.printStackTrace();
                	}
            }
        }
    }
   
}
