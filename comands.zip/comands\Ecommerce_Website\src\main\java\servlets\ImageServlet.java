package servlets;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import utils.DBUtils;
import utils.LoggerUtil;

@WebServlet("/ImageServlet")
public class ImageServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final Logger logger = LoggerUtil.getLogger(ImageServlet.class);
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String imgIdParam = request.getParameter("imgId");
        String productIdParam = request.getParameter("productId");
        
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            
            // Handle image by imgId (from M_S_PRODUCT_IMAGES)
            if (imgIdParam != null && !imgIdParam.isEmpty()) {
                int imgId = Integer.parseInt(imgIdParam);
                String sql = "SELECT image_data, content_type FROM Ecommerce_Website.M_S_PRODUCT_IMAGES WHERE id = ?";
                ps = conn.prepareStatement(sql);
                ps.setInt(1, imgId);
                rs = ps.executeQuery();
                
                if (rs.next()) {
                    byte[] imageData = rs.getBytes("image_data");
                    String contentType = rs.getString("content_type");
                    
                    if (imageData != null && imageData.length > 0) {
                        serveImage(response, imageData, contentType);
                        return;
                    }
                }
            }
            
            // Handle primary image by productId (from M_S_DATAS or M_S_PRODUCT_IMAGES)
            if (productIdParam != null && !productIdParam.isEmpty()) {
                int productId = Integer.parseInt(productIdParam);
                
                // First try to get primary image from M_S_PRODUCT_IMAGES
                String sql = "SELECT TOP 1 image_data, content_type " +
                           "FROM Ecommerce_Website.M_S_PRODUCT_IMAGES " +
                           "WHERE product_id = ? " +
                           "ORDER BY is_primary DESC, id ASC";
                ps = conn.prepareStatement(sql);
                ps.setInt(1, productId);
                rs = ps.executeQuery();
                
                if (rs.next()) {
                    byte[] imageData = rs.getBytes("image_data");
                    String contentType = rs.getString("content_type");
                    
                    if (imageData != null && imageData.length > 0) {
                        serveImage(response, imageData, contentType);
                        return;
                    }
                }
                
                // Fallback: try M_S_DATAS table
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                
                sql = "SELECT image FROM Ecommerce_Website.M_S_DATAS WHERE product_id = ?";
                ps = conn.prepareStatement(sql);
                ps.setInt(1, productId);
                rs = ps.executeQuery();
                
                if (rs.next()) {
                    byte[] imageData = rs.getBytes("image");
                    if (imageData != null && imageData.length > 0) {
                        // Detect content type from byte signature
                        String contentType = detectContentType(imageData);
                        serveImage(response, imageData, contentType);
                        return;
                    }
                }
            }
            
            // No image found - return 404
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Image not found");
            
        } catch (NumberFormatException e) {
            logger.error("Invalid image ID or product ID", e);
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid ID format");
        } catch (SQLException e) {
            logger.error("Database error while fetching image", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        } finally {
            if (rs != null) try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            if (ps != null) try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
            if (conn != null) try { conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
    
    private void serveImage(HttpServletResponse response, byte[] imageData, String contentType) 
            throws IOException {
        
        if (contentType == null || contentType.isEmpty()) {
            contentType = detectContentType(imageData);
        }
        
        response.setContentType(contentType);
        response.setContentLength(imageData.length);
        
        // Enable caching for images
        response.setHeader("Cache-Control", "public, max-age=31536000");
        response.setDateHeader("Expires", System.currentTimeMillis() + 31536000000L);
        
        try (OutputStream out = response.getOutputStream()) {
            out.write(imageData);
            out.flush();
        }
    }
    
    private String detectContentType(byte[] imageData) {
        if (imageData == null || imageData.length < 4) {
            return "image/jpeg"; // default
        }
        
        // Check PNG signature
        if (imageData[0] == (byte) 0x89 && imageData[1] == 0x50 && 
            imageData[2] == 0x4E && imageData[3] == 0x47) {
            return "image/png";
        }
        
        // Check JPEG signature
        if (imageData[0] == (byte) 0xFF && imageData[1] == (byte) 0xD8) {
            return "image/jpeg";
        }
        
        // Check GIF signature
        if (imageData[0] == 0x47 && imageData[1] == 0x49 && imageData[2] == 0x46) {
            return "image/gif";
        }
        
        // Check WebP signature
        if (imageData.length >= 12 && 
            imageData[0] == 0x52 && imageData[1] == 0x49 && 
            imageData[2] == 0x46 && imageData[3] == 0x46 &&
            imageData[8] == 0x57 && imageData[9] == 0x45 && 
            imageData[10] == 0x42 && imageData[11] == 0x50) {
            return "image/webp";
        }
        
        return "image/jpeg"; // default fallback
    }
}