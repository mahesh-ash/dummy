
$(document).ready(function () {
  $.getJSON("register.json", function (data) {
    renderForm(data.fields);
  });


  function renderForm(fields) {
    const $form = $("#registrationForm").empty();
   
    fields.forEach(field => {
      let fieldHtml = "";
      switch (field.inputType) {
        case "text":
        case "email":
        case "password":
        case "phone":
          fieldHtml = `
            <div>
              <label for="${field.id}" class="block font-semibold">${field.title}${field.mandatory ? ' <span class="text-red-500">*</span>' : ''}</label> 
              <input type="${field.inputType}" id="${field.id}" name="${field.id}" class="w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500" ${field.mandatory ? "required" : ""}>
              <p id="${field.id}-error" class="text-red-500 text-sm hidden"></p> 
            </div>
          `;
          break;
        case "number":
          fieldHtml = `
            <div>
              <label for="${field.id}" class="block font-semibold">${field.title}${field.mandatory ? ' <span class=\"text-red-500\">*</span>' : ''}</label>
              <input type="number" id="${field.id}" name="${field.id}" class="w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500" ${field.mandatory ? "required" : ""} min="100000" max="999999">
              <p id="${field.id}-error" class="text-red-500 text-sm hidden"></p>
            </div>
          `;
          break;

        case "radio":
          fieldHtml = `
            <div>
              <label class="block font-semibold">${field.title}</label>
              ${field.options.map(opt => `
                <label class="mr-4">
                  <input type="radio" name="${field.id}" value="${opt.value}"> ${opt.text}
                </label>
              `).join("")}
            </div>
          `;
          break;

        case "select":
          fieldHtml = `
            <div>
              <label for="${field.id}" class="block font-semibold">${field.title}</label>
              <select id="${field.id}" name="${field.id}" class="w-full border rounded-lg p-2" ${field.mandatory ? "required" : ""}>
                ${field.options.map(opt => `<option value="${opt.value}">${opt.text}</option>`).join("")}
              </select>
            </div>
          `;
          break;

        case "multiselect":
          fieldHtml = `
            <div>
              <label class="block font-semibold">${field.title}</label>
              <select id="${field.id}" name="${field.id}" multiple="multiple">
                ${field.options.map(opt => `<option value="${opt.value}">${opt.text}</option>`).join("")}
              </select>
            </div>
          `;
          break;

        case "textarea":
          fieldHtml = `
            <div>
              <label for="${field.id}" class="block font-semibold">${field.title}</label>
              <textarea id="${field.id}" name="${field.id}" class="w-full border rounded-lg p-2" ${field.mandatory ? "required" : ""}></textarea>
            </div>
          `;
          break;

        case "button":
          fieldHtml = `
            <div>
              <button type="submit" id="${field.id}" class="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700">
                ${field.title}
              </button>
            </div>
          `;
          break;
      }
      $form.append(fieldHtml);
    });

    fields.forEach(field => {
      if (field.validation) {
        $(`#${field.id}`).on("input", function () {
          const regex = new RegExp(field.validation.pattern);
          let val = $(this).val();
          // Special validation for pincode
          if (field.id === "pincode") {
            if (!/^[0-9]{6}$/.test(val)) {
              $(`#${field.id}-error`).text("Pincode must be a 6-digit number").removeClass("hidden");
            } else {
              $(`#${field.id}-error`).addClass("hidden");
            }
            return;
          }
          if (!regex.test(val)) {
            $(`#${field.id}-error`).text(field.validation.message).removeClass("hidden");
          } else {
            $(`#${field.id}-error`).addClass("hidden");
          }
        });
      }
    });
    
    $("#confirm_password").on("input",function(){
      const password=$("#password").val();
      const confirm=$(this).val();
      if(password!=confirm){
        $(`#confirm_password-error`).text("Passwords do not match").removeClass("hidden");
      }
      else{
      $(`#confirm_password-error`).addClass("hidden");
      }
    });

    $("#password").on("input",function(){
        $("#confirm_password").trigger("input");
    });

    $form.on("submit", function (e) {
      e.preventDefault();
      try {
        const student = {};
        let valid = true;

        fields.forEach(field => {
          if (field.inputType === "button") return;

          let value;
          if (field.inputType === "radio") {
            value = $(`input[name="${field.id}"]:checked`).val() || "";
          } else if (field.inputType === "multiselect") {
            value = $(`#${field.id}`).val() || [];
          } else {
            value = $(`#${field.id}`).val();
          }
           if (field.id === "confirm_password") {
           const password = $("#password").val().trim();
        if (password !== value) {
          return false;

        }
           }


          if (field.mandatory && (!value || value.length === 0)) {
            alert(`${field.title} is required`);
            valid = false;
            return false;
          }

          // Special validation for pincode
          if (field.id === "pincode" && !/^[0-9]{6}$/.test(value)) {
            alert("Pincode must be a 6-digit number");
            valid = false;
            return false;
          }

          if (field.validation) {
            const regex = new RegExp(field.validation.pattern);
            if (!regex.test(value)) {
              alert(field.validation.message);
              valid = false;
              return false;
            }
          }
          student[field.id] = value;
        });

        if (!valid) return;
        debugger
console.log($form.serialize());
    $.ajax({
    url: "http://localhost:8080/Ecommerce_Website/RegisterServlet", 
    type: "POST",
    data:$form.serialize(),
    success: function (response) {
         console.log("Exexuted");
        window.location.href = "login.html";
  
    },
    error: function () {
      debugger
      alert("Server error. Please try again later.");
    }
  });

        alert("Register successfully!");
      } catch (error) {
        console.error("Submit error:", error);
        alert("Error while saving the student.");
      }
    });
  }
});