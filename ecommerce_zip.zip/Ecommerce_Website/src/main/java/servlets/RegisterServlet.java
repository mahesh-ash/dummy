package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;
import model.User;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("fname");
        String email = request.getParameter("email");
        System.out.println("email"+email);
        String password = request.getParameter("password");
        String mobile = request.getParameter("phone");
        String address = request.getParameter("full_address");
        
        int pincode = 0; 
        try {
        	
            String pincodeStr = request.getParameter("pincode");
            if (pincodeStr != null && !pincodeStr.isEmpty()) {
                pincode = Integer.parseInt(pincodeStr);
                System.out.println("Pincode: "+pincode);
            }
        } catch (NumberFormatException e) {
            response.sendRedirect("register.html?error=Invalid pincode format.");
            return; 
        }

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setMobile(mobile);
        user.setAddress(address);
        user.setPinCode(pincode);


        UserDao userDao = new UserDao();
        boolean success = userDao.registerUser(user);

        if (success) {
            response.sendRedirect("login.html?message=Registration successful! Please log in.");
        } else {
            response.sendRedirect("register.html?error=Registration failed. Please try again.");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
