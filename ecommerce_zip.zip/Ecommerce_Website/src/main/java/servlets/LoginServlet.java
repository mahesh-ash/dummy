package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.JsonObject;

import dao.UserDao;
import model.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        JsonObject jsonResponse = new JsonObject();
        
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        UserDao userService = new UserDao();
        String status = userService.isValid(email, password);
        
        if ("valid".equalsIgnoreCase(status)) {
            User user = userService.getUserDetails(email);
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            jsonResponse.addProperty("status", "success");
            jsonResponse.addProperty("redirectUrl", "navbar.html");
        } else {
        	System.out.println("entered");
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("redirectUrl", "login.html?error=Registration failed. Please sign up.");
        }
        
        response.getWriter().write(jsonResponse.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
