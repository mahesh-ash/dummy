package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson; // You will need to add the Gson library to your project
import com.google.gson.GsonBuilder;

import dao.ProductDao;
import model.Product;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ProductDao<?> productDao;
    private Gson gson;

    @Override
    public void init() throws ServletException {
        super.init();
        this.productDao = new ProductDao<Object>();
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }
    
  
    	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    		response.setContentType("application/json");
    	    PrintWriter out = response.getWriter();

    	    List<Product> products;
    	    String categoryIdParam = request.getParameter("category_id");
    	    String query = request.getParameter("query");
            System.out.println(query);
    	    if (query != null) {
    	        query = query.trim();
    	        query = query.replaceAll("[^a-zA-Z0-9 ]", "");
    	       // System.out.println(query);
    	        if (query.length() > 50) {
    	            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
    	            out.print("{\"error\": \"Query too long\"}");
    	            return;
    	        }
    	    }

    	    try {
    	    	//System.out.println("IT will executed");
    	        if (categoryIdParam != null && !categoryIdParam.isEmpty()) {
    	            int categoryId = Integer.parseInt(categoryIdParam);
    	            if (query != null && !query.isEmpty()) {
    	                products = productDao.searchProductsByCategoryAndName(categoryId, query);
    	            } else {
    	                products = productDao.getProductsByCategoryId(categoryId);
    	            }
    	        } else {
    	            if (query != null && !query.isEmpty()) {
    	            	//System.out.println("inside loop");
    	                products = productDao.searchProductsByName(query);
    	            } else {
    	            	//System.out.println("query is null");
    	                products = productDao.getAllProducts();
    	            }
    	        }
    	    } catch (NumberFormatException e) {
    	        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
    	        out.print("{\"error\": \"Invalid category_id format\"}");
    	        return;
    	    }

    	    String jsonProducts = gson.toJson(products);
    	    out.print(jsonProducts);
    	    out.flush();
    	}


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
    
}

