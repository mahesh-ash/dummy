package dao;

import model.User;

public interface UserInterface {
    String isValid(String email,String password) ;
    User getUserDetails(String email);
    boolean registerUser(User u);
}
