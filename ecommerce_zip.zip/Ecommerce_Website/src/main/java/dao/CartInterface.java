package dao;

import java.sql.SQLException;
import java.util.List;

import model.CartItem;

public interface CartInterface {

	void addToCart(int userId, int productId, int qty) throws SQLException;

	void updateQuantity(int userId, int productId, int qty) throws SQLException;

	void removeFromCart(int userId, int productId) throws SQLException;

	List<CartItem> getCartItems(int userId) throws SQLException;

	void clearCart(int userId) throws SQLException;

}
