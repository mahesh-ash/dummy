package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.User;
import utils.DBUtils;

	public class UserDao implements UserInterface {

	   
		  public boolean registerUser(User u) {
		        String sql = "insert into Ecommerce_Website.M_S_USER(fullname, email, phone, password, address, pincode) values(?,?,?,?,?,?)";
		        try (Connection c = DBUtils.getConnection();
		             PreparedStatement ps = c.prepareStatement(sql)) {
		            System.out.println("Connection Executed Successfully");
		            ps.setString(1, u.getName());
		            ps.setString(2, u.getEmail());
		            ps.setString(3, u.getMobile());
		            ps.setString(4, u.getPassword());
		            ps.setString(5, u.getAddress());
		            ps.setInt(6, u.getPinCode());
		            return ps.executeUpdate() > 0;
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		        return false;
		    }
public String isValid(String email, String password) {
       String status = "Invalid Username or Password";
       String sql = "SELECT * FROM Ecommerce_Website.M_S_USER WHERE email=? AND password=?";
       try (Connection conn = DBUtils.getConnection();
       PreparedStatement ps = conn.prepareStatement(sql)) {
       ps.setString(1, email);
       ps.setString(2, password);
       ResultSet rs = ps.executeQuery();
       if (rs.next()) {
         status = "valid";
      }
     } catch (SQLException e) {
       e.printStackTrace();
 }
   return status;
}
			


public User getUserDetails(String email) {
 User user = null;
 String sql = "SELECT * FROM Ecommerce_Website.M_S_USER WHERE email=?";
 try (Connection conn = DBUtils.getConnection();
      PreparedStatement ps = conn.prepareStatement(sql)) {
     ps.setString(1, email);
     ResultSet rs = ps.executeQuery();
     if (rs.next()) {
         user = new User(
             rs.getString("fullname"),
             rs.getString("phone"),
             rs.getString("email"),
             rs.getString("address"),
             rs.getInt("pincode"),
             rs.getString("password")
         );
     }
 } catch (SQLException e) {
     e.printStackTrace();
 }
 return user;
}
	}





