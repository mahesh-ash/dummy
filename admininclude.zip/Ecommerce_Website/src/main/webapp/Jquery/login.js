$(document).ready(function () {


  $.getJSON("../Jquery/Login.json", function (data) {
    renderStudentsData(data.Inputfields);
  });

  function validateField(field) {
    const $input = $("#" + field.id);
    const value = $input.val().trim();
    let isValid = true;
    $input.next(".text-red-500").remove();

    if (field.mandatory && field.enable) {
      if (!value) {
        isValid = false;
        $input.addClass("border-red-500").removeClass("border-indigo-500");
        $input.after(
          `<p class="text-red-500 text-sm mt-1">${field.title} is required.</p>`
        );
      } else if (field.inputType === "email") {
        const emailPattern = /^[A-Za-z0-9]+@[A-Za-z0-9]+\.[A-Za-z]{2,}$/;
        if (!emailPattern.test(value)) {
          isValid = false;
          $input.addClass("border-red-500").removeClass("border-indigo-500");
          $input.after(
            '<p class="text-red-500 text-sm mt-1">Please enter a valid email address.</p>'
          );
        }
      } else if (field.id === "fname") {
        const namePattern = /^[A-Za-z]+$/;
        if (!namePattern.test(value)) {
          isValid = false;
          $input.addClass("border-red-500").removeClass("border-indigo-500");
          $input.after(
            '<p class="text-red-500 text-sm mt-1">Name should contain only letters</p>'
          );
        }
      } else if (field.id == "password") {
        const passwordPattern =
          /^(?=.*[A-Z])(?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/;
        if (!passwordPattern.test(value)) {
          isValid = false;
          $input.addClass("border-red-500").removeClass("border-indigo-500");
          $input.after(
            '<p class="text-red-500 text-sm mt-1">Password must contain at least 6 characters, one uppercase, one number, and one special character</p>'
          );
        }
      }
    }

    if (isValid) {
      $input.removeClass("border-red-500").addClass("border-indigo-500");
    }
    return isValid;
  }

  function renderStudentsData(fields) {
    const $form = $("#registrationForm").empty();

    fields.forEach((field) => {
      let fieldHtml = "";
      const requiredAttr = field.mandatory ? "required" : "";
      const disabledAttr = !field.enable ? "disabled" : "";
      const commonClasses = `w-full px-4 py-2 border rounded-lg shadow-sm focus:outline-none transition ${
        !field.enable ? "bg-gray-200 cursor-not-allowed" : "bg-white"
      } border-gray-300`;

      switch (field.inputType) {
        case "text":
        case "email":
          fieldHtml = `
            <div class="relative">
              <label class="block text-gray-700 font-semibold mb-1">${field.title}${
            field.mandatory ? '<span class="text-red-500">*</span>' : ""
          }</label>
              <input type="${field.inputType}" id="${field.id}" name="${field.id}" 
                class="${commonClasses}" placeholder="Enter your ${field.title}" ${requiredAttr} ${disabledAttr} />
            </div>`;
          break;
          case "phone":
            fieldHtml = `
              <div class="relative">
                <label class="block text-gray-700 font-semibold mb-1">${field.title}${
              field.mandatory ? '<span class="text-red-500">*</span>' : ""
            }</label>
                <input type="tel" id="${field.id}" name="${field.id}" 
                  class="${commonClasses}" placeholder="Enter your ${field.title}" pattern="[0-9]{10}" maxlength="10" ${requiredAttr} ${disabledAttr} />
              </div>`;
            break;

        case "password":
          fieldHtml = `
            <div class="relative">
              <label class="block text-gray-700 font-semibold mb-1">${field.title}${
            field.mandatory ? '<span class="text-red-500">*</span>' : ""
          }</label>
              <input type="password" id="${field.id}" name="${field.id}" 
                class="${commonClasses}" placeholder="Enter your ${field.title}" ${requiredAttr} ${disabledAttr} />
            </div>`;
          break;

        case "button":
          fieldHtml = `
            <button id="${field.id}" type="submit" 
              class="w-full bg-indigo-600 text-white font-semibold py-3 rounded-lg shadow hover:bg-indigo-700 transition duration-300" ${disabledAttr}>
              ${field.title}
            </button>`;
          break;
      }

      $form.append(`<div class="mb-6">${fieldHtml}</div>`);
    });
    fields.forEach((field) => {
      if (
        ["text", "email", "textarea", "phone", "password"].includes(
          field.inputType
        )
      ) {
        $("#" + field.id).on("input change blur", function () {
          validateField(field);
        });
      }
    });



    $(document).ready(function () {
      function setActiveNav(page) {
        $(".navbar-btn").removeClass("bg-blue-600 text-white");
        $("#nav-" + page).addClass("bg-blue-600 text-white");
      }
      $("#nav-login").click(function () { 
        window.location.href = "login.html";
       });
      $("#nav-register").click(function () { 
        window.location.href = "register.html";
       });
      $("#nav-products").click(function () {
         window.location.href = "index.html"; 
        });
      $("#nav-back").click(function () { 
        window.history.back(); 
      });

      if (window.location.pathname.includes("login.html")) setActiveNav("login");
      else if (window.location.pathname.includes("register.html")) setActiveNav("register");
      else if (window.location.pathname.includes("index.html")) setActiveNav("products");
    });
    $(document).ready(function () {
      $("#back-btn").click(function () {
        window.history.back();
      });
    });
    $(document).ready(function () {
      $("#category-dropdown-btn").click(function (e) {
        e.stopPropagation();
        $("#category-dropdown").toggle();
      });
      $(document).click(function () {
        $("#category-dropdown").hide();
      });
      $("#category-dropdown").click(function (e) {
        e.stopPropagation();
      });
      $(document).on("click", ".dropdown-category", function () {
        let cat = $(this).data("cat");
        alert("Selected category: " + cat);
        $("#category-dropdown").hide();
      });
    });

    $form.on("submit", function (e) {
      e.preventDefault();
      let isValid = true;
      $(".text-red-500").remove();

      fields.forEach((field) => {
        if (!validateField(field)) isValid = false;
      });

      if (!isValid) return;

      const formData = {};
      fields.forEach((field) => {
        if (field.inputType !== "button") {
          formData[field.id] = $("#" + field.id).val().trim();
        }
      });
      const Data=$form.serialize();
      console.log($form.serialize());
     $.ajax({
    url: "http://localhost:8080/Ecommerce_Website/LoginServlet",
    type: "POST",
    data: Data,
    dataType: "json", 
    success: function(response) {
        console.log(response);
        if (response.status === "success") {
            window.location.href = response.redirectUrl;
        } else {
            alert("check your email and password");
            window.location.href = response.redirectUrl;
        }
    },
    error: function() {
        alert("Server error. Please try again later.");
    }
});



      $form[0].reset();
    });
  }
});
