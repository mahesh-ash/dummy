package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.User;
import utils.DBUtils;

public class UserDao {

    public boolean registerUser(User u) {
        String sql = "INSERT INTO Ecommerce_Website.M_S_USER(fullname, email, phone, password, address, pincode) VALUES(?,?,?,?,?,?)";
        try (Connection c = DBUtils.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            System.out.println("Connection Executed Successfully");
            ps.setString(1, u.getName());
            ps.setString(2, u.getEmail());
            ps.setString(3, u.getMobile());
            ps.setString(4, u.getPassword());
            ps.setString(5, u.getAddress());
            ps.setInt(6, u.getPinCode());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public String isValid(String email, String password) {
        String status = "Invalid Username or Password";
        String sql = "SELECT * FROM Ecommerce_Website.M_S_USER WHERE email=? AND password=?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                status = "valid";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }


    public User getUserDetails(String email) {
        User user = null;
        String sql = "SELECT user_id, fullname, phone, email, address, pincode, password FROM Ecommerce_Website.M_S_USER WHERE email=?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                user = new User();
                user.setId(rs.getInt("user_id"));
                user.setName(rs.getString("fullname"));
                user.setMobile(rs.getString("phone"));
                user.setEmail(rs.getString("email"));
                user.setAddress(rs.getString("address"));
                user.setPinCode(rs.getInt("pincode"));
                user.setPassword(rs.getString("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }
    

    public static User getUserByEmail(String email) throws SQLException {
        User user = null;
        String sql = "SELECT id, fullname, phone, address, pincode, password FROM Ecommerce_Website.M_S_USER WHERE email = ?"; 
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    user = new User();
                    user.setId(rs.getInt("id"));
                    user.setEmail(email);
                    user.setName(rs.getString("fullname"));
                    user.setMobile(rs.getString("phone"));
                    user.setAddress(rs.getString("address"));
                    user.setPinCode(rs.getInt("pincode"));
                    user.setPassword(rs.getString("password"));
                }
            }
        }
        return user;
    }

    public boolean updateUser(User user) throws SQLException {
        String sql = "UPDATE Ecommerce_Website.M_S_USER SET fullname=?, phone=?, address=?, pincode=?, updatedat=GETDATE() WHERE user_id=?";
        try (Connection c = DBUtils.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            
            ps.setString(1, user.getName());
            ps.setString(2, user.getMobile());
            ps.setString(3, user.getAddress());
            ps.setInt(4, user.getPinCode());
            ps.setInt(5, user.getId());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        }
    }
    }





