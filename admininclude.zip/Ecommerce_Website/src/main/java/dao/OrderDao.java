package dao;

import model.Order;
import model.OrderItem;
import utils.DBUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDao {


    public static List<Order> getOrderHistory(int userId) throws SQLException {
        List<Order> orders = new ArrayList<>();
        String ordersSql = "SELECT * FROM Ecommerce_Website.D_D_ORDER WHERE user_id = ? ORDER BY orderdate DESC";
        
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(ordersSql)) {
            
            ps.setInt(1, userId);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Order order = new Order();
                    order.setOrderId(rs.getInt("order_id"));
                    order.setUserId(rs.getInt("user_id"));
                    order.setTotalAmount(rs.getDouble("total_amount"));
                    order.setOrderDate(rs.getTimestamp("orderdate"));
                    order.setStatus(rs.getString("status"));

                    order.setItems(getOrderItems(conn, order.getOrderId()));
                    orders.add(order);
                }
            }
        }
        return orders;
    }



    private static List<OrderItem> getOrderItems(Connection conn, int orderId) throws SQLException {
        List<OrderItem> items = new ArrayList<>();
        String itemsSql = "SELECT ol.*, p.product_name FROM Ecommerce_Website.D_D_ORDERLOGS ol " +
                          "JOIN Ecommerce_Website.M_S_DATAS p ON ol.product_id = p.product_id " +
                          "WHERE ol.order_id = ?";

        
        try (PreparedStatement ps = conn.prepareStatement(itemsSql)) {
            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    OrderItem item = new OrderItem();
                    item.setOrderLogId(rs.getInt("id"));
                    item.setOrderId(rs.getInt("order_id"));
                    item.setProductId(rs.getInt("product_id"));
                    item.setProductName(rs.getString("product_name"));
                    item.setQuantity(rs.getInt("quantity"));
                    item.setPrice(rs.getDouble("price"));
                    item.setTotal(rs.getDouble("total"));
                    items.add(item);
                }
            }
        }
        return items;
    }
}

