package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.JsonObject;

import dao.UserDao;
import model.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
    private static final String ADMIN_EMAIL = "admin@gmail.com";
    private static final String ADMIN_PASSWORD = "Admin@123";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        JsonObject jsonResponse = new JsonObject();

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        System.out.println(email+" "+password);
        if (ADMIN_EMAIL.equalsIgnoreCase(email) && ADMIN_PASSWORD.equals(password)) {
            HttpSession session = request.getSession();
            session.setAttribute("isAdmin", true);

            jsonResponse.addProperty("status", "success");
            jsonResponse.addProperty("redirectUrl", "Admin.html");
            response.getWriter().write(jsonResponse.toString());
            return; 
        }

        
        UserDao userService = new UserDao();
        String status = userService.isValid(email, password);

        if ("valid".equalsIgnoreCase(status)) {
            User user = userService.getUserDetails(email);
            HttpSession session = request.getSession();
            

            session.setAttribute("userId", user.getId()); 
            session.setAttribute("user", user);
            session.setAttribute("userEmail", email);
            
            jsonResponse.addProperty("status", "success");
            jsonResponse.addProperty("redirectUrl", "navbar.html");
        } else {
            System.out.println("entered");
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("redirectUrl", "login.html?error=Registration failed. Please sign up.");
        }
        
        response.getWriter().write(jsonResponse.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}

