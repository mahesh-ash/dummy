package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import utils.DBUtils;

@WebServlet("/ChangeServlet")
public class ChangeServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            out.println("<h3>You must be logged in to change your password.</h3>");
            return;
        }
        String email = (String) session.getAttribute("userEmail");
        System.out.println(email);

        String newPass = req.getParameter("newPassword");
        String confirmPass = req.getParameter("confirmPassword");
        
        if(!newPass.equals(confirmPass)) {
        	 out.println("<h3>Error: passwords do not match</h3>");
        	 return ;
        }
        if ( newPass == null || newPass.trim().isEmpty()) {
            out.println("<h3>Error: All password fields are required.</h3>");
            return;
        }

        System.out.println("User trying to change password: " + email);

        try (Connection con = DBUtils.getConnection()) {
            String selectSql = "SELECT password FROM Ecommerce_Website.M_S_USER WHERE email=?";
            try (PreparedStatement ps = con.prepareStatement(selectSql)) {
                ps.setString(1, email);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                    	System.out.println("Entered");
                        String updateSql = "UPDATE Ecommerce_Website.M_S_USER SET password=? WHERE email=?";
                        try (PreparedStatement update = con.prepareStatement(updateSql)) {
                            update.setString(1, newPass);
                            update.setString(2, email);
                            update.executeUpdate();
                            out.println("<h3>Password changed successfully!</h3>");
                        }
                    } 
                }
            }
        } catch (Exception e) {
            e.printStackTrace(out);
            out.println("<h3>An error occurred during password change.</h3>");
        }
    }
}
