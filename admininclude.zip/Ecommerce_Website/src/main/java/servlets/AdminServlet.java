package servlets;

import dao.AdminDao;
import model.Admin;
import model.Product;
import model.User;
import com.google.gson.Gson;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
    private final AdminDao dao = new AdminDao();
    private final Gson gson = new Gson();

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String action = req.getParameter("action");
        res.setContentType("application/json");

        try {
            if ("listUsers".equals(action)) {
                List<User> users = dao.getAllUsers();
                res.getWriter().write(gson.toJson(users));
            } else if ("getAdmin".equals(action)) {
                HttpSession session = req.getSession(false);
                System.out.println("admin: "+""+session);
                if (session != null && session.getAttribute("admin") != null) {
                    Admin admin = (Admin) session.getAttribute("admin");
                    res.getWriter().write(gson.toJson(admin));
                } else {
                	System.out.println("Admin not logged in");
                    res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                    res.getWriter().write("{\"error\":\"Admin not logged in\"}");
                }
            } else {
                res.getWriter().write("{\"error\":\"Unknown or unsupported action for GET\"}");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            res.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String action = req.getParameter("action");
        System.out.println(action);
        res.setContentType("application/json");

        try {
            switch (action) {
            case "login":
                String username = req.getParameter("username");
                String password = req.getParameter("password");
                Admin admin = dao.login(username, password);
                System.out.println("ADmin is: "+admin);
                if (admin != null) {
                    HttpSession session = req.getSession();
                    session.setAttribute("admin", admin);
                    
                    res.getWriter().write("{\"status\":\"success\"}");
                } else {
                    res.getWriter().write("{\"status\":\"fail\"}");
                }
                break;

                case "deleteUser":
                    int uid = Integer.parseInt(req.getParameter("userId"));
                    if (dao.deleteUser(uid)) {
                        res.getWriter().write("{\"status\":\"ok\"}");
                    } else {
                        res.getWriter().write("{\"status\":\"fail\"}");
                    }
                    break;

                case "toggleStatus":
                    int userId = Integer.parseInt(req.getParameter("userId"));
                    boolean active = Boolean.parseBoolean(req.getParameter("active"));
                    if (dao.updateUserStatus(userId, active)) {
                        res.getWriter().write("{\"status\":\"ok\"}");
                    } else {
                        res.getWriter().write("{\"status\":\"fail\"}");
                    }
                    break;

                case "listProducts":
                    List<Product> products = dao.getAllProducts();
                    res.getWriter().write(gson.toJson(products));
                    break;

                case "addProduct":
                    Product p = new Product(
                        Integer.parseInt(req.getParameter("categoryId")),
                        req.getParameter("productName"),
                        req.getParameter("description"),
                        Double.parseDouble(req.getParameter("price")),
                        Integer.parseInt(req.getParameter("stock")),
                        req.getParameter("image")
                    );
                    if (dao.addProduct(p)) {
                        res.getWriter().write("{\"status\":\"ok\"}");
                    } else {
                        res.getWriter().write("{\"status\":\"fail\"}");
                    }
                    break;

                case "deleteProduct":
                    int pid = Integer.parseInt(req.getParameter("productId"));
                    if (dao.deleteProduct(pid)) {
                        res.getWriter().write("{\"status\":\"ok\"}");
                    } else {
                        res.getWriter().write("{\"status\":\"fail\"}");
                    }
                    break;
                
                default:
                    res.getWriter().write("{\"error\":\"Unknown action\"}");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            res.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }
}
