package model;

// Ensure this class has all the fields needed by the front-end
public class Admin {
    private int adminId;
    private String username;
    private String email; // Add the email field
    // Add other fields as needed, e.g., 'name' if your DB stores it

    // Add appropriate constructors and getters/setters for the new field
    public Admin(int adminId, String username, String email) {
        this.adminId = adminId;
        this.username = username;
        this.email = email;
    }

    // Getters and setters...
    public int getAdminId() { return adminId; }
    public String getUsername() { return username; }
    public String getEmail() { return email; } // Added getter
}
