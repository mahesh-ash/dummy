package model;

import java.util.ArrayList;
import java.util.List;

public class Paymentrequest {
    private Double amount;
    private String cardHolder;
    private String cardLast4;
    private String expMonth;
    private String expYear;
    private List<Integer> selectedItems = new ArrayList<>();


    public Paymentrequest() {
        super();
    }

    public Paymentrequest(Double amount, String cardHolder, String cardLast4, String expMonth, String expYear) {
        super();
        this.amount = amount;
        this.cardHolder = cardHolder;
        this.cardLast4 = cardLast4;
        this.expMonth = expMonth;
        this.expYear = expYear;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    public String getCardLast4() {
        return cardLast4;
    }

    public void setCardLast4(String cardLast4) {
        this.cardLast4 = cardLast4;
    }

    public String getExpMonth() {
        return expMonth;
    }

    public void setExpMonth(String expMonth) {
        this.expMonth = expMonth;
    }

    public String getExpYear() {
            return expYear;
    }

    public void setExpYear(String expYear) {
        this.expYear = expYear;
    }

    public List<Integer> getSelectedItems() {
        return selectedItems;
    }

    public void setSelectedItems(List<Integer> selectedItems) {
        this.selectedItems = selectedItems;
    }
}
