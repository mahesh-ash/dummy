package Packages;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

   
	    public boolean registerUser(User u){
	        try{
	            Connection c=DBConnection.getConnection();
	            System.out.println("Connection Executed Successfully");
	            PreparedStatement ps=c.prepareStatement("insert into Ecommerce_Projects.Users(username,password,email) values(?,?,?)");
	            ps.setString(1,u.getUsername());
	            ps.setString(2,u.getPassword());
	            ps.setString(3,u.getEmail());
	            return ps.executeUpdate()>0;
	        }catch(Exception e){
	        	e.printStackTrace();
	        	}
	        return false;
	    }
	    public boolean loginUser(String un,String pw){
	        try{
	            Connection c=DBConnection.getConnection();
	            PreparedStatement ps=c.prepareStatement("select * from Ecommerce_Projects.Users where username=? and password=?");
	            ps.setString(1,un);
	            ps.setString(2,pw);
	            ResultSet rs=ps.executeQuery();
	            return rs.next();
	        }catch(Exception e){
	        	e.printStackTrace();
	        }
	        return false;
	    }
	    public List<String> getProducts() {
	        List<String> list = new ArrayList<>();
	        try {
	            Connection con = DBConnection.getConnection();
	            Statement st = con.createStatement();
	            ResultSet rs = st.executeQuery("SELECT name, price FROM Ecommerce_Projects.products");
	            while(rs.next()) {
	                list.add(rs.getString("name")+" - ₹"+rs.getDouble("price"));
	            }
	        } catch(Exception e){ 
	        	e.printStackTrace();
	       }
	        return list;
	    }
       }
	

