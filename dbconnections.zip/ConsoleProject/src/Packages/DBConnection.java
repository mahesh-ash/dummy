package Packages;

import java.sql.*;
public class DBConnection {
	private static String url="jdbc:sqlserver://192.168.3.125:1433;database=SQLTraining";
	private static String Username="DzTrainee";
	private static String Password= "Sql!2025";

	    private DBConnection(){
	    	
	    }
        public static void main(String[] args) {
        	getConnection();
        }
	 
	    public static Connection getConnection(){
	    	Connection connection=null;
	    	try {
	    	
	  
	    		Class.forName("jdbc:sqlserver://192.168.3.125:1433;database=SQLTraining");
	    		connection=DriverManager.getConnection(url,Username,Password);
	    		System.out.println("Connection Successfull");		
	    	}
	       catch(Exception e){
	    	   System.out.println("DBconnection failed");
	    	   e.printStackTrace();
	       }
	           
	        return connection;
	    }
	}





