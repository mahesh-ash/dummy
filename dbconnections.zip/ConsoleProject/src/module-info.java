module ConsoleProject {
	requires java.sql;
}