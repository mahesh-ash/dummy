package dao;

import model.User;
import model.Product;
import model.Admin;
import utils.DBUtils;
import java.sql.*;
import java.util.*;

public class AdminDao {

	public Admin login(String username, String password) throws SQLException {
	    String sql = "SELECT * FROM  Ecommerce_Website.ADMINS WHERE username = ? AND password = ?";
	    try (Connection c = DBUtils.getConnection();
	         PreparedStatement ps = c.prepareStatement(sql)) {
	        ps.setString(1, username);
	        ps.setString(2, password);
	        try (ResultSet rs = ps.executeQuery()) {
	            if (rs.next()) {
	                return new Admin(rs.getInt("admin_id"), rs.getString("username"), rs.getString("email"));
	            }
	        }
	    }
	    return null;
	}
    public List<User> getAllUsers() throws SQLException {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM Ecommerce_Website.M_S_USER";
        try (Connection c = DBUtils.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                User u = new User();
                u.setId(rs.getInt("user_id"));
                u.setName(rs.getString("fullname"));
                u.setEmail(rs.getString("email"));
                u.setMobile(rs.getString("phone"));
                u.setAddress(rs.getString("address"));
                u.setPinCode(rs.getInt("pincode"));
                u.setPassword(rs.getString("password"));
                list.add(u);
            }
        }
        return list;
    }
    

    public boolean deleteUser(int userId) throws SQLException {
        String sql = "DELETE FROM Ecommerce_Website.M_S_USER WHERE user_id=?";
        try (Connection c = DBUtils.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean updateUserStatus(int userId, boolean active) throws SQLException {
        String sql = "UPDATE Ecommerce_Website.M_S_USER SET status=? WHERE user_id=?";
        try (Connection c = DBUtils.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setBoolean(1, active);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        }
    }

    public List<Product> getAllProducts() throws SQLException {
        return new ProductDao<>().getAllProducts();
    }

    public boolean addProduct(Product p) throws SQLException {
        String sql = "INSERT INTO Ecommerce_Website.M_S_DATAS(category_id, product_name, description, price, stock, image) VALUES(?,?,?,?,?,?)";
        try (Connection c = DBUtils.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, p.getCategoryId());
            ps.setString(2, p.getProductName());
            ps.setString(3, p.getDescription());
            ps.setDouble(4, p.getPrice());
            ps.setInt(5, p.getStock());
            ps.setString(6, p.getImageUrl());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean updateProduct(Product p) throws SQLException {
        String sql = "UPDATE Ecommerce_Website.M_S_DATAS SET category_id=?, product_name=?, description=?, price=?, stock=?, image=? WHERE product_id=?";
        try (Connection c = DBUtils.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, p.getCategoryId());
            ps.setString(2, p.getProductName());
            ps.setString(3, p.getDescription());
            ps.setDouble(4, p.getPrice());
            ps.setInt(5, p.getStock());
            ps.setString(6, p.getImageUrl());
            ps.setInt(7, p.getProductId());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean deleteProduct(int productId) throws SQLException {
        String sql = "DELETE FROM Ecommerce_Website.M_S_DATAS WHERE product_id=?";
        try (Connection c = DBUtils.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, productId);
            return ps.executeUpdate() > 0;
        }
    }
    public boolean changePassword(int adminId, String currentPassword, String newPassword) throws SQLException {
        String checkSql = "SELECT * FROM Ecommerce_Website.ADMINS WHERE admin_id=? AND password=?";
        try (Connection c = DBUtils.getConnection();
             PreparedStatement ps = c.prepareStatement(checkSql)) {
            ps.setInt(1, adminId);
            ps.setString(2, currentPassword);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return false; // current password wrong
            }
        }

        String updateSql = "UPDATE Ecommerce_Website.ADMINS SET password=? WHERE admin_id=?";
        try (Connection c = DBUtils.getConnection();
             PreparedStatement ps = c.prepareStatement(updateSql)) {
            ps.setString(1, newPassword);
            ps.setInt(2, adminId);
            return ps.executeUpdate() > 0;
        }
    }

}