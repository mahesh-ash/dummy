package servlets;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
// other imports...

import dao.UserDao;
import model.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String ADMIN_EMAIL = "admin@gmail.com";
    private static final String ADMIN_PASSWORD = "Admin@123";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // ensure JSON + utf-8
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        JsonObject jsonResponse = new JsonObject();
        Gson gson = new Gson();

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        System.out.println(email + " " + password);

        if (ADMIN_EMAIL.equalsIgnoreCase(email) && ADMIN_PASSWORD.equals(password)) {
            HttpSession session = request.getSession();
            
            // Create a User-like object for Admin
            User adminUser = new User();
            adminUser.setId(0);
            adminUser.setName("Admin");
            adminUser.setEmail(ADMIN_EMAIL);
//            adminUser.setActive(true); // optional if field exists
            
            // Save both flags for clarity
            session.setAttribute("user", adminUser);
            session.setAttribute("isAdmin", true);
            
            JsonObject jsonResponse1 = new JsonObject();
            jsonResponse1.addProperty("status", "success");
            jsonResponse1.addProperty("redirectUrl", "Admin.html");
            jsonResponse1.add("user", new Gson().toJsonTree(adminUser));
            
            response.getWriter().write(jsonResponse1.toString());
            return;
        }


        UserDao userService = new UserDao();
        String status = userService.isValid(email, password);

        if ("valid".equalsIgnoreCase(status)) {
            User user = userService.getUserDetails(email);
            HttpSession session = request.getSession();

            session.setAttribute("userId", user.getId());
            session.setAttribute("user", user);
            session.setAttribute("userEmail", email);

            jsonResponse.addProperty("status", "success");
            jsonResponse.addProperty("redirectUrl", "navbar.html");
            // add the user object to JSON response
            jsonResponse.add("user", gson.toJsonTree(user));
        } else {
            System.out.println("entered");
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("redirectUrl", "login.html?error=Registration failed. Please sign up.");
        }

        response.getWriter().write(jsonResponse.toString());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
