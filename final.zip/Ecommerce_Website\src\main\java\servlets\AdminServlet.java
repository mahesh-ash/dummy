package servlets;

import com.google.gson.Gson;
import dao.AdminDao;
import dao.OrderDao;
import model.Order;
import model.Product;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {

    private final AdminDao dao = new AdminDao();
    private final Gson gson = new Gson();

    private boolean isAdminLoggedIn(HttpSession session) {
        return session != null && session.getAttribute("isAdmin") != null && (Boolean) session.getAttribute("isAdmin");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String action = req.getParameter("action");
        res.setContentType("application/json");
        res.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession(false);

        try {
            switch (action) {

                case "listUsers":
                    if (!isAdminLoggedIn(session)) {
                        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        res.getWriter().write("{\"error\":\"Admin not logged in\"}");
                        return;
                    }
                    List<User> users = dao.getAllUsers();
                    res.getWriter().write(gson.toJson(users));
                    break;

                case "getAdmin":
                    if (!isAdminLoggedIn(session)) {
                        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        res.getWriter().write("{\"error\":\"Admin not logged in\"}");
                        return;
                    }
                    User adminUser = (User) session.getAttribute("user");
                    res.getWriter().write(gson.toJson(adminUser));
                    break;

                case "listOrders":
                    if (!isAdminLoggedIn(session)) {
                        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        res.getWriter().write("{\"error\":\"Admin not logged in\"}");
                        return;
                    }
                    List<Order> orders = OrderDao.getOrderHistoryForAll();
                    res.getWriter().write(gson.toJson(orders));
                    break;

                default:
                    res.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    res.getWriter().write("{\"error\":\"Unknown GET action\"}");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            res.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String action = req.getParameter("action");
        res.setContentType("application/json");
        res.setCharacterEncoding("UTF-8");
        HttpSession session = req.getSession(false);

        try {
            switch (action) {

                // ---------------- LOGOUT ----------------
                case "logout":
                    if (session != null) session.invalidate();
                    res.getWriter().write("{\"status\":\"ok\"}");
                    break;

                // ---------------- PRODUCT ACTIONS ----------------
                case "listProducts":
                    if (!isAdminLoggedIn(session)) {
                        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        res.getWriter().write("{\"error\":\"Admin not logged in\"}");
                        return;
                    }
                    List<Product> products = dao.getAllProducts();
                    res.getWriter().write(gson.toJson(products));
                    break;

                case "addProduct":
                    if (!isAdminLoggedIn(session)) {
                        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        res.getWriter().write("{\"error\":\"Admin not logged in\"}");
                        return;
                    }
                    Product newProduct = new Product(
                            Integer.parseInt(req.getParameter("categoryId")),
                            req.getParameter("productName"),
                            req.getParameter("description"),
                            Double.parseDouble(req.getParameter("price")),
                            Integer.parseInt(req.getParameter("stock")),
                            req.getParameter("image")
                    );
                    res.getWriter().write(dao.addProduct(newProduct) ? "{\"status\":\"ok\"}" : "{\"status\":\"fail\"}");
                    break;

                case "updateProduct":
                    if (!isAdminLoggedIn(session)) {
                        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        res.getWriter().write("{\"error\":\"Admin not logged in\"}");
                        return;
                    }
                    Product updateProduct = new Product(
                            Integer.parseInt(req.getParameter("productId")),
                            Integer.parseInt(req.getParameter("categoryId")),
                            req.getParameter("productName"),
                            req.getParameter("description"),
                            Double.parseDouble(req.getParameter("price")),
                            Integer.parseInt(req.getParameter("stock")),
                            req.getParameter("image")
                    );
                    res.getWriter().write(dao.updateProduct(updateProduct) ? "{\"status\":\"ok\"}" : "{\"status\":\"fail\"}");
                    break;

                case "deleteProduct":
                    if (!isAdminLoggedIn(session)) {
                        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        res.getWriter().write("{\"error\":\"Admin not logged in\"}");
                        return;
                    }
                    int pid = Integer.parseInt(req.getParameter("productId"));
                    res.getWriter().write(dao.deleteProduct(pid) ? "{\"status\":\"ok\"}" : "{\"status\":\"fail\"}");
                    break;

                // ---------------- USER ACTIONS ----------------
                case "deleteUser":
                    if (!isAdminLoggedIn(session)) {
                        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        res.getWriter().write("{\"error\":\"Admin not logged in\"}");
                        return;
                    }
                    int uid = Integer.parseInt(req.getParameter("userId"));
                    res.getWriter().write(dao.deleteUser(uid) ? "{\"status\":\"ok\"}" : "{\"status\":\"fail\"}");
                    break;

                case "toggleStatus":
                    if (!isAdminLoggedIn(session)) {
                        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        res.getWriter().write("{\"error\":\"Admin not logged in\"}");
                        return;
                    }
                    int userId = Integer.parseInt(req.getParameter("userId"));
                    boolean active = Boolean.parseBoolean(req.getParameter("active"));
                    res.getWriter().write(dao.updateUserStatus(userId, active) ? "{\"status\":\"ok\"}" : "{\"status\":\"fail\"}");
                    break;

                // ---------------- PASSWORD CHANGE ----------------
                case "changePassword":
                    if (!isAdminLoggedIn(session)) {
                        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                        res.getWriter().write("{\"error\":\"Admin not logged in\"}");
                        return;
                    }
                    User adminUserPwd = (User) session.getAttribute("user");
                    String current = req.getParameter("currentPassword");
                    String newPass = req.getParameter("newPassword");
                    res.getWriter().write(dao.changePassword(adminUserPwd.getId(), current, newPass) ? "{\"status\":\"ok\"}" : "{\"status\":\"fail\"}");
                    break;

                default:
                    res.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    res.getWriter().write("{\"error\":\"Unknown POST action\"}");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            res.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
        } catch (NumberFormatException e) {
            res.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            res.getWriter().write("{\"error\":\"Invalid numeric input\"}");
        }
    }
}
