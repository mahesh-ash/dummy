package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Product;
import utils.DBUtils;
public class ProductDao<getProductsByCategoryId> implements ProductInterface {

    @Override
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM Ecommerce_Website.M_S_DATAS";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Product product = new Product(
                    rs.getInt("product_id"),
                    rs.getInt("category_id"),
                    rs.getString("product_name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getInt("stock"),
                    rs.getString("image")
                );
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    @Override
    public List<Product> getProductsByCategoryId(int categoryId) {
        ArrayList<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM Ecommerce_Website.M_S_DATAS WHERE category_id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, categoryId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Product product = new Product(
                        rs.getInt("product_id"),
                        rs.getInt("category_id"),
                        rs.getString("product_name"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("stock"),
                        rs.getString("image")
                    );
                    products.add(product);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }
    


	@Override
    public List<Product> searchProductsByName(String query) {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM Ecommerce_Website.M_S_DATAS WHERE product_name LIKE ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + query + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Product product = new Product(
                        rs.getInt("product_id"),
                        rs.getInt("category_id"),
                        rs.getString("product_name"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("stock"),
                        rs.getString("image")
                    );
                    products.add(product);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }
   @Override
    public List<Product> searchProductsByCategoryAndName(int categoryId, String query) {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM Ecommerce_Website.M_S_DATAS WHERE category_id = ? AND product_name LIKE ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, categoryId);
            ps.setString(2, "%" + query + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Product product = new Product(
                        rs.getInt("product_id"),
                        rs.getInt("category_id"),
                        rs.getString("product_name"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("stock"),
                        rs.getString("image")
                    );
                    products.add(product);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }
   
   public List<Product> getFilteredProducts(Integer categoryId, String query, String filter) {
       List<Product> products = new ArrayList<>();
       StringBuilder sql = new StringBuilder("SELECT * FROM Ecommerce_Website.M_S_DATAS WHERE 1=1");

       if (categoryId != null) sql.append(" AND category_id = ?");
       if (query != null && !query.isEmpty()) sql.append(" AND (LOWER(product_name) LIKE ? OR LOWER(description) LIKE ?)");

       if (filter != null) {
           switch (filter) {
               case "low-high": sql.append(" ORDER BY price ASC"); break;
               case "high-low": sql.append(" ORDER BY price DESC"); break;
             
           }
       }

       try (Connection conn = DBUtils.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql.toString())) {

           int i = 1;
           if (categoryId != null) ps.setInt(i++, categoryId);
           if (query != null && !query.isEmpty()) {
               String like = "%" + query.toLowerCase() + "%";
               ps.setString(i++, like);
               ps.setString(i++, like);
           }

           try (ResultSet rs = ps.executeQuery()) {
               while (rs.next()) products.add(mapProduct(rs));
           }

       } catch (SQLException e) { e.printStackTrace(); }
       return products;
   }
   private Product mapProduct(ResultSet rs) throws SQLException {
       return new Product(
           rs.getInt("product_id"),
           rs.getInt("category_id"),
           rs.getString("product_name"),
           rs.getString("description"),
           rs.getDouble("price"),
           rs.getInt("stock"),
           rs.getString("image")
         
       );
   }


    
    
}



