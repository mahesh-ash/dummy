package servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import dao.CartDao;
import model.CartItem;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private CartDao cartDao = new CartDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	System.out.println("Do get method invoked");
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        

        HttpSession session = request.getSession(false);
        int userId = (Integer) session.getAttribute("userId");
        
        try {
            List<CartItem> items = cartDao.getCartItems(userId);
            response.getWriter().print(gson.toJson(items));
            
        } catch (SQLException e) {
        	System.out.println("Error occured: " + e.getMessage());
            response.setStatus(500);
            response.getWriter().print("{\"error\":\"DB error\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        

        HttpSession session = request.getSession(false);
        int userId = (Integer) session.getAttribute("userId");
        System.out.println(userId);
        try {
            if ("add".equals(action)) {
                int productId = Integer.parseInt(request.getParameter("productId"));
                int qty = 1;
                try { 
                	qty = Integer.parseInt(request.getParameter("qty")); 
                	} catch (NumberFormatException e) {

                        System.out.println("Invalid quantity, using default 1.");
                	}
                cartDao.addToCart(userId, productId, qty);
                System.out.println("add block entered");
            }
            else if ("update".equals(action)) {
            	System.out.println("update block entered");
                int productId = Integer.parseInt(request.getParameter("productId"));
                int qty = Integer.parseInt(request.getParameter("qty"));
                cartDao.updateQuantity(userId, productId, qty);
            }
            else if ("remove".equals(action)) {
            	System.out.println("remove block entered");
                int productId = Integer.parseInt(request.getParameter("productId"));
                cartDao.removeFromCart(userId, productId);
            } 
            else if ("clear".equals(action)) {
            	System.out.println("clear block entered");
                cartDao.clearCart(userId);
            }
            
            List<CartItem> items = cartDao.getCartItems(userId);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().print(gson.toJson(items));
        } catch (SQLException e) {
            System.out.println("Error occurred: " + e.getMessage());
            response.setStatus(500);
            response.getWriter().print("{\"error\":\"DB error\"}");
        }
    }
}
