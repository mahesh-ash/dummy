package dao;

import java.util.List;

import model.Product;

public interface ProductInterface {
    List<Product> getAllProducts();
    List<Product> getProductsByCategoryId(int categoryId);
	List<Product> searchProductsByCategoryAndName(int categoryId, String query);
	List<Product> searchProductsByName(String query);
	List<Product> getFilteredProducts(Integer categoryId, String query, String sortType);
}
