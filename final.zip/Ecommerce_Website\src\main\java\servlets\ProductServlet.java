

package servlets;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.google.gson.*;
import dao.ProductDao;
import model.Product;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ProductDao<?> productDao;
    private Gson gson;

    @Override
    public void init() throws ServletException {
        this.productDao = new ProductDao<>();
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        String categoryIdParam = request.getParameter("category_id");
        String query = request.getParameter("query");
        String filter = request.getParameter("filter");

        Integer categoryId = null;
        if (categoryIdParam != null && !categoryIdParam.isEmpty()) {
            try {
                categoryId = Integer.parseInt(categoryIdParam);
            } catch (NumberFormatException e) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"error\":\"Invalid category_id\"}");
                return;
            }
        }

        if (query != null) query = query.trim().replaceAll("[^a-zA-Z0-9 ]", "");

        List<Product> products = productDao.getFilteredProducts(categoryId, query, filter);
        out.print(gson.toJson(products));
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}