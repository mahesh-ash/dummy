//package servlets;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.sql.SQLException;
//import java.util.List;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//import com.google.gson.Gson;
//import com.google.gson.GsonBuilder;
//
//import dao.CartDao;
//import model.CartItem;
//
//@WebServlet("/DBCartServlet")
//public class DBCartServlet extends HttpServlet {
//    private static final long serialVersionUID = 1L;
//    private Gson gson = new GsonBuilder().setPrettyPrinting().create();
//    private CartDao cartDao = new CartDao();
//
//    private int getUserId(HttpSession session) {
//        Object uid = session.getAttribute("userId");
//        if (uid instanceof Integer) return (Integer) uid;
//        return 1;
//    }
//
//    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        response.setContentType("application/json");
//        response.setCharacterEncoding("UTF-8");
//        HttpSession session = request.getSession(true);
//        int userId = getUserId(session);
//        try {
//            List<CartItem> items = cartDao.getCartItems(userId);
//            response.getWriter().print(gson.toJson(items));
//        } catch (SQLException e) {
//            response.setStatus(500);
//            response.getWriter().print("{\"error\":\"DB error\"}");
//        }
//    }
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        String action = request.getParameter("action");
//        HttpSession session = request.getSession(true);
//        int userId = getUserId(session);
//        try {
//            if ("add".equals(action)) {
//                int productId = Integer.parseInt(request.getParameter("productId"));
//                int qty = 1;
//                try { qty = Integer.parseInt(request.getParameter("qty")); } catch (Exception e) {}
//                cartDao.addToCart(userId, productId, qty);
//            } else if ("update".equals(action)) {
//                int productId = Integer.parseInt(request.getParameter("productId"));
//                int qty = Integer.parseInt(request.getParameter("qty"));
//                cartDao.updateQuantity(userId, productId, qty);
//            } else if ("remove".equals(action)) {
//                int productId = Integer.parseInt(request.getParameter("productId"));
//                cartDao.removeFromCart(userId, productId);
//            } else if ("clear".equals(action)) {
//                cartDao.clearCart(userId);
//            }
//            List<CartItem> items = cartDao.getCartItems(userId);
//            response.setContentType("application/json");
//            response.setCharacterEncoding("UTF-8");
//            response.getWriter().print(gson.toJson(items));
//        } catch (SQLException e) {
//            response.setStatus(500);
//            response.getWriter().print("{\"error\":\"DB error\"}");
//        }
//    }
//}
