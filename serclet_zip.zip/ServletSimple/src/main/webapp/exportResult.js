
function exportResultsToCSV(results) {
    if (!results || results.length === 0) consoloe.log("No output Produced");

    let csv = "Test Name,Result\n";
    results.forEach(r => csv += `${r.name},${r.result}\n`);

    const blob = new Blob([csv], { type: "text/csv" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "JSUnit_TestResults.csv";
    link.click();
}/**
 * 
 */