package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Packages.User;
import Packages.UserDao;

public class ServletSimpleClass extends HttpServlet {

    private static final long serialVersionUID = 1L;
    UserDao lib = new UserDao();

    public void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String action = req.getParameter("action");
        System.out.println(action + "Username");
        
        System.out.println(action);

        if ("register".equals(action)) {
            String u = req.getParameter("username");
            String p = req.getParameter("password");
            String e = req.getParameter("email");
            
            User user = new User(u, p, e);
            
            if (lib.registerUser(user)) {
                out.println("Registered Successfully! <a href='login.html'>Login</a>");
            } else {
                out.println("Registration Failed! <a href='register.html'>Try Again</a>");
            }
            return;
        }

        else if ("login".equals(action)) { 
            String u = req.getParameter("username");
            System.out.println(u + "Username");
            String p = req.getParameter("password");
            if (lib.loginUser(u, p)) {
                System.out.println("Session Created Successfully");
                HttpSession session = req.getSession();
                
                if(session != null) {
                    System.out.println("User exist");
                    session.setAttribute("username", u);
                    
                }
                res.setStatus(200);
                System.out.println("Hii");
                res.sendRedirect("home.html");
            } else {
                out.println("Invalid Login! <a href='login.html'>Try Again</a>");
            }
            return;
        }
    }
    
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        resp.setContentType("text/html");

        HttpSession session = req.getSession(false);

        if (session == null || session.getAttribute("username") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        PrintWriter out = resp.getWriter();
        String action = req.getParameter("action");

        System.out.println(action);


        if (action == null) {
            resp.sendRedirect("home.html");
            return;
        }

        switch (action) {
            case "products":
                out.println("<h2>Products</h2>");
                out.println("<p>List of products will be displayed here.</p>");
                break;
            case "history":
                out.println("<h2>Order History</h2>");
                out.println("<p>User order history will be displayed here.</p>");
                break;
            case "logout":
                session.invalidate(); 
                resp.sendRedirect("login.html");
                break;
            default:
                resp.sendRedirect("home.html");
                break;
        }
    }
}
