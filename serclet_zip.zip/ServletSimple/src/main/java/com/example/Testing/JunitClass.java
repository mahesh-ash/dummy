package com.example.Testing;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class JunitClass {
    
	
	@Test
	public void getMessage() {
		String name="hello";
		assertEquals("hello", name);
		System.out.println("Successfull");
	}
}
