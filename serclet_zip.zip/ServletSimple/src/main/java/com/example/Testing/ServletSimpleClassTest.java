//package com.example.Testing;
//
//import com.example.ServletSimpleClass;
//import org.junit.Before;
//import org.junit.Test;
//import javax.servlet.*;
//import javax.servlet.http.*;
//import java.io.*;
//import static org.junit.Assert.*;
//
//public class ServletSimpleClassTest {
//
//    private ServletSimpleClass servlet;
//
//    @Before
//    public void setUp() {
//        servlet = new ServletSimpleClass();
//    }
//
//    @Test
//    public void testValidLoginRedirectsToHome() throws Exception {
//        SimpleRequest req = new SimpleRequest();
//        SimpleResponse res = new SimpleResponse();
//
//        req.setParameter("username", "Maheshwaran");
//        req.setParameter("password", "Mahesh@123");
//
//        servlet.doPost(req, res);
//
//        assertEquals("home.html", res.getRedirectedUrl());
//    }
//
//
//    class SimpleRequest extends HttpServletRequestWrapper {
//        private java.util.Map<String, String> params = new java.util.HashMap<>();
//        private SimpleSession session;
//
//        public SimpleRequest() { 
//        	super(new EmptyRequest()); 
//        	}
//
//        public void setParameter(String k, String v) {
//        	params.put(k, v); 
//        	}
//        public String getParameter(String k) { 
//        	return params.get(k);
//        	}
//
//        public HttpSession getSession(boolean create) {
//            if (session == null && create)
//            	session = new SimpleSession();
//            return session;
//        }
//    }
//
//    class SimpleResponse extends HttpServletResponseWrapper {
//        private String redirectUrl;
//        public SimpleResponse() { 
//        	super(new EmptyResponse()); 
//        	}
//        public void sendRedirect(String loc) { 
//        	redirectUrl = loc; 
//        	}
//        public String getRedirectedUrl() { 
//        	return redirectUrl;
//        	}
//    }
//
//    class SimpleSession implements HttpSession {
//        private java.util.Map<String, Object> attrs = new java.util.HashMap<>();
//        public Object getAttribute(String name) {
//        	return attrs.get(name);
//        }
//        public void setAttribute(String name, Object value) { 
//        	attrs.put(name, value);
//        	}
//        public void invalidate() {
//        	attrs.clear();
//        }
//        public boolean isNew() {
//        	return false; 
//        	}
//        public long getCreationTime() {
//        	return 0; 
//        	}
//        public String getId() { 
//        	return "1";
//        	}
//
//        public ServletContext getServletContext() { return null; }
//        public void setMaxInactiveInterval(int i) {}
//        public int getMaxInactiveInterval() { return 0; }
//        public HttpSessionContext getSessionContext() { return null; }
//        public Object getValue(String s) { return null; }
//        public java.util.Enumeration<String> getAttributeNames() { return java.util.Collections.enumeration(attrs.keySet()); }
//        public String[] getValueNames() { return new String[0]; }
//        public void putValue(String s, Object o) {}
//        public void removeAttribute(String s) { attrs.remove(s); }
//        public void removeValue(String s) {}
//		@Override
//		public long getLastAccessedTime() {
//			return 0;
//		}
//    }
//
//    static class EmptyRequest extends HttpServletRequestWrapper { public EmptyRequest() { super(null); } }
//    static class EmptyResponse extends HttpServletResponseWrapper { public EmptyResponse() { super(null); } }
//}