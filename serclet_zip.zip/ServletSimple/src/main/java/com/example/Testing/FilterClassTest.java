//package com.example.Testing;
//
//
//
//
//import com.example.Util.FilterClass;
//import org.junit.Before;
//import org.junit.Test;
//import javax.servlet.*;
//import javax.servlet.http.*;
//import java.io.*;
//import static org.junit.Assert.*;
//
//public class FilterClassTest {
//
//    private FilterClass filter;
//
//    @Before
//    public void setUp() {
//        filter = new FilterClass();
//    }
//
//    @Test
//    public void testRedirectIfSessionMissing() throws Exception {
//        SimpleRequest req = new SimpleRequest("/home.html");
//        SimpleResponse res = new SimpleResponse();
//
//        filter.doFilter(req, res, (r1, r2) -> res.getWriter().write("allowed"));
//
//        assertEquals("login.html", res.getRedirectedUrl());
//    }
//
//
//    class SimpleRequest extends HttpServletRequestWrapper {
//        private String uri;
//        public SimpleRequest(String uri) { super(new EmptyRequest()); this.uri = uri; }
//        public String getRequestURI() { return uri; }
//        public HttpSession getSession(boolean create) { return null; }
//    }
//
//    class SimpleResponse extends HttpServletResponseWrapper {
//        private String redirectUrl;
//        private StringWriter sw = new StringWriter();
//        private PrintWriter pw = new PrintWriter(sw);
//        public SimpleResponse() {
//        	super(new EmptyResponse()); 
//        }
//        public PrintWriter getWriter() { 
//        	return pw; 
//        	}
//        public void sendRedirect(String loc) {
//        	redirectUrl = loc; 
//        	}
//        public String getRedirectedUrl() { 
//        	return redirectUrl;
//        	}
//    }
//
//    static class EmptyRequest extends HttpServletRequestWrapper { 
//    	public EmptyRequest() {
//    		super(null); 
//    	} 
//    	}
//    static class EmptyResponse extends HttpServletResponseWrapper { 
//    	public EmptyResponse() { 
//    		super(null); 
//    		} 
//    	}
//}
//
