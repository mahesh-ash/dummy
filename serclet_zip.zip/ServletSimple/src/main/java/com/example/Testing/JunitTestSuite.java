package com.example.Testing;

import org.junit.runner.RunWith;
import org.junit.runners.Suite.SuiteClasses;

import com.example.ServletSimpleClass;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({

   ServletSimpleClass.class
})

public class JunitTestSuite {  
	
} 

