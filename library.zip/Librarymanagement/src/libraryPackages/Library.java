package libraryPackages;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class Library implements Searchable{
  private List<Book>books;
  private List<Member>members;
  
  public Library() {
	  books=new ArrayList<>();
	  members=new ArrayList<>();
  }
  
  void addBooks(Book book) {
	  books.add(book);
	  LoggerClass.logger.info(book.getTitle()+" book added");
//	  System.out.println(book.getTitle()+" book added ");
  }
  
  void removeBooks(Book book) {
	  books.remove(book);
	  LoggerClass.logger.info(book.getTitle()+" book removed");
  }
  
  
  public void registerMember(Member member) {
	members.add(member);
	 LoggerClass.logger.info("member.getName()" +"registered Successfully");
//	System.out.println(member.getName()+" registered Successfully");
  }
  
  public Book findBookByID(int id) {
	  for(Book b: books) {
		  if(b.getId()==id) {
			  return b;
		  }
	  }
	  LoggerClass.logger.warn("Invalid Book Id");
	  return null;
  }
  
  public Member findMemberById(int id) {
	  for(Member m: members) {
		  if(m.getMemberId()==id) {
			  return m;
		  }
	  }
	  LoggerClass.warn("Invalid Book Id");
	  return null;
  }
  
  
  public void showAllbooks() {
	  System.out.println("--Library Books Details ----");
	  for(Book b:books) {
		  b.display();
	  }
  }
  

public void SearchBytitle(String keyword) {
	
	List<Book>result = books.stream()
			.filter(p -> p.getTitle().equalsIgnoreCase(keyword)).collect(Collectors.toList());
	
	if(result.isEmpty()) {
        LoggerClass.error("Item not found");
//		System.out.println("Item not found");
	}
	else {
		result.forEach(Book::display);
	}
	
}

public void filterByauthor(String author) {
	List<Book>result = books.stream()
			.filter(p -> p.getAuthor().equalsIgnoreCase(author)).collect(Collectors.toList());
	
	if(result.isEmpty()) {
		LoggerClass.logger.error("Item not found");
//		System.out.println("Item not found");
	}
	else {
		result.forEach(Book::display);
	}
	
}


  
}
