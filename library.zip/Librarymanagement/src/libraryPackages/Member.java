package libraryPackages;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;

public abstract class Member {
   protected int memberId;
   protected String name;
   protected String role;
   protected Map<Book,LocalDate>borrowedbooks;
public Member(int memberId, String name,String role) {
	super();
	this.memberId = memberId;
	this.name = name;
	this.role=role;
	this.borrowedbooks = new HashMap<>();
}
public int getMemberId() {
	return memberId;
}
public void setMemberId(int memberId) {
	this.memberId = memberId;
}
public String getName() {
	return name;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public Map<Book, LocalDate> getBorrowedbooks() {
	return borrowedbooks;
}
public void setBorrowedbooks(Map<Book, LocalDate> borrowedbooks) {
	this.borrowedbooks = borrowedbooks;
}
public void setName(String name) {
	this.name = name;
}

public abstract int getMaxBooks();

public abstract int getFine();

public boolean borrowBook(Book book,LocalDate borrowDate) {
	if(borrowedbooks.size()>=getMaxBooks()) {
//		System.out.println(name+" already reached limit");
		LoggerClass.warn(" Reached max borrowCount "+name);
		return false;
	}
	if(book.getAvailablecount()>0) {
		borrowedbooks.put(book,borrowDate);
		book.setAvailablecount(book.getAvailablecount()-1);
		System.out.println(name+ " borrowed "+book.getTitle());
		return true;
	}
	else {
		 System.out.println("Book not available");
		 return false;
	}
}

public void returnBook(Book book) {
	if(borrowedbooks.containsKey(book)) {
		LocalDate borrowDate=borrowedbooks.get(book);
		LocalDate returDate=LocalDate.now();
		
		long days=ChronoUnit.DAYS.between(borrowDate, returDate);
		
		borrowedbooks.remove(book);
		book.setAvailablecount(book.getAvailablecount()+1);
		
		long fine= (days>7) ?(days-7)*getFine():0;
		if(fine==0) {
			System.out.println(name+ " returned "+book.getTitle());
		}
		else {
			LoggerClass.warn(name+"give Fine Rs."+fine);
//		System.out.println(name+ " give Fine Rs."+fine);
		}
		
		
	}
	else {
		System.out.println(name+" is not borrowed any books");
	}
}

public void borrowedDeatails() {
	if(borrowedbooks.isEmpty()) {
		System.out.println(name+" has not borrowed any books");
	}
	else {
		System.out.println(name+" has borrowed books");
	}
	System.out.println("BorrowedbookDeatails");
	for(Map.Entry<Book,LocalDate>entry:borrowedbooks.entrySet()) {
		System.out.println("--"+entry.getKey().getTitle()+" (Borrowed on :)"+entry.getValue()+"--");
	}
	
}
   
   
   
}
