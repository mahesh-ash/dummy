package libraryPackages;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class LoggerClass {
//	public static final Logger logger = LogManager.getLogger(LibraryMainClass.class);
	
	 public static final Logger logger = LogManager.getLogger("CentralLogger");
       public static void main(String args) {
    	   
    	   
    	   getCaller();
       }
	    public static String getCaller() {
	        StackTraceElement caller = Thread.currentThread().getStackTrace()[3];
////	        System.out.println("HOI");
//	        System.out.println(caller);
	        return caller.getClassName() + ":" + caller.getLineNumber();
	    }

	    public static void info(String msg) {
	        logger.info(getCaller() + " - " + msg);
	    }

	    public static void debug(String msg) {
	        logger.debug(getCaller() + " - " + msg);
	    }

	    public static void error(String msg) {
	        logger.error(getCaller() + " - " + msg);
	    }

		public static void trace(String msg) {
			logger.trace(getCaller()+"-"+msg);
			
		}

		public static void warn(String msg) {
			logger.warn(getCaller()+"-"+msg);
			
		}

}
