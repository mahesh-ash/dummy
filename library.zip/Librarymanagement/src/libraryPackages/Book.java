package libraryPackages;

public class Book {
   private int id;
   private String title;
   private String author;
private double price;
   private int availablecount;
   public Book(int id, String title,String author, double price, int availablecount) {
	   super();
	   this.id = id;
	   this.title=title;
	   this.author = author;
	   this.price = price;
	   this.availablecount = availablecount;
	   LoggerClass.trace("Book Created");
   }
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}
public double getPrice() {
	return price;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public void setPrice(double price) {
	this.price = price;
}
public int getAvailablecount() {
	return availablecount;
}
public void setAvailablecount(int availablecount) {
	this.availablecount = availablecount;
}
   public void display() {
	   System.out.println(id+" | "+title+" | "+author+" | "+"$ "+price+" | "+availablecount);
   }
}
