package libraryPackages;

public interface Searchable {
  void SearchBytitle(String keyword);
  void filterByauthor(String Keyword);
  
}
