package libraryPackages;

public class Admin {
  private String username;
  private String password;
public Admin(String username, String password) {
	super();
	this.username = username;
	this.password = password;
}
  
  public boolean login(String user,String pass) {
	  return username.equals(user) && password.equals(pass);
  }
  
  
  public void addbook(Library lib,Book book) {
	  try {
		 LoggerClass.debug("Admin try to add a book");
		lib.addBooks(book);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		LoggerClass.error("Admin Can't add the book");
		e.printStackTrace();
	}
  }
  
  public void deleteBook(Library lib,int bookId) {
	  Book b=lib.findBookByID(bookId);
	  if(b!=null) {
		  lib.removeBooks(b);
		  LoggerClass.info("b.getTitle()+\" book deleted");
//		  System.out.println(b.getTitle()+" book deleted");
	  }
	  else {
		  LoggerClass.error("b.getTitle()+\" Book was not found");
//		  System.out.println(b.getTitle()+" Book was not found");
	  }
  }
	

}
