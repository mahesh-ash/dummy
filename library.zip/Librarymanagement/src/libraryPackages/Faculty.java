package libraryPackages;

public class Faculty extends Member {

	public Faculty(int memberId, String name) {
		super(memberId, name,"faculty");
		LoggerClass.info("Fauculty should be added here");
	}

	@Override
	public int getMaxBooks() {
		return 10;
	}

	@Override
	public int getFine() {
		return 10;
	}

}
