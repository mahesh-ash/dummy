package libraryPackages;

public class Student extends Member {
    public Student(int id,String name) {
    	super(id,name,"student");
    }

	@Override
	public int getMaxBooks() {
		return 5;
	}

	@Override
	public int getFine() {
		return 15;
	}
}
