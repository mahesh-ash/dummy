//package libraryPackages;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//public class Dummy {
//    private static final Logger logger = LogManager.getLogger(Dummy.class);
//
//    public static void main(String[] args) {
//        logger.debug("This is a debug message.");
//        logger.info("This is an info message.");
//        logger.warn("This is a warning message.");
//        logger.error("This is an error message.");
//        logger.fatal("This is a fatal message.");
//        try {
//            int res = 10 / 0;
//            System.out.println(res);
//        } catch (Exception e) {
//            logger.error("An error occurred during division", e);
//        }
//    }
//}
