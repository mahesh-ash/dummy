package libraryPackages;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;


import org.apache.log4j.xml.DOMConfigurator;






public class LibraryMainClass {
   static Scanner scanner=new Scanner(System.in);
   static Library lib=new Library();
    static Admin admin=new Admin("admin","admin@123");
    
    



	private static LocalDate date;
    
    
    public static void adminMenu() {
    	System.out.println("Enter Admin USername");
    	String username=scanner.nextLine();
    	System.out.println("Enter Admin Password");
    	String Password=scanner.nextLine();
    	
    	if(admin.login(username,Password)) {
//    		System.out.println("Login Successfull");
    		LoggerClass.info("Login Sucessfull");
    		
    		int choice;
    		do {
    			System.out.println("Admin Menu");
    			System.out.println("1.Add Book");
    			System.out.println("2.Delete Book");
    			System.out.println("3.Back");
    			choice=getValidate("Enter your choice");
    			
    			switch(choice) {
    			case 1:
    				addBookMenu();
    				break;
    			case 2:
    				removeBookMenu();
    				break;
    			}
    		}while(choice!=3);
    	}
    	else {
    		LoggerClass.info("Invalid admin Credentials");
//    		System.out.println("Invalid admin Credentials");
    	}
    }

    private static int getValidate(String prompt) {
		while(true) {
			try {
				System.out.println(prompt);
				return Integer.parseInt(scanner.next());
			}catch(NumberFormatException e) {
				System.out.println("Invalid Input");
			}
		}

	}

	private static void addBookMenu() {
    	System.out.println("Enter the Book id: ");
    	int id=scanner.nextInt();
    	scanner.nextLine();
    	System.out.println("Enter the Book title");
    	String title=scanner.nextLine();
    	System.out.println("Enter the author name");
    	String author=scanner.nextLine();
    	System.out.println("Enter the Price");
    	double price=scanner.nextDouble();
    	System.out.println("total Count of books");
    	int availableCount=scanner.nextInt();
    	Book b=new Book(id,title,author,price,availableCount);
    	admin.addbook(lib, b);
    	
    	
    	
    }

	private static void removeBookMenu() {
		
		System.out.println("Enter the Book Id to Delete");
		int bookId=scanner.nextInt();
		admin.deleteBook(lib, bookId);
	}
	
	private static void registerMemberMenu() {
		System.out.println("Enter Role (Faculty/Student)");
		scanner.nextLine();
		System.out.println("Enter Member Id: ");
		int memberId=scanner.nextInt();
		scanner.nextLine();
		System.out.println("Enter Member Name");
		String name=scanner.nextLine();
		Member m;
		System.out.println("1-Student,2-Faculty");
		int roleChoice=scanner.nextInt();
		if(roleChoice==1) {
			m=new Student(memberId,name);
		}
		else {
			m=new Faculty(memberId,name);
		}
		lib.registerMember(m);
		
	}
	
	public static void main(String args[]) {
		
		ch();
		
		
		
		
		
		
	    LoggerClass.info("The Application has been Started");
		int choice;
		do {
			System.out.println("1.Admin Login");
			System.out.println("2.Register Members");
			System.out.println("3.show All Books");
			System.out.println("4.Borrow Books");
			System.out.println("5.Return Books");
			System.out.println("6.View Borrorwed Books");
			System.out.println("7.SearchByItem Name");
			System.out.println("8.SearchByAuthor Name");
			System.out.println("9.Exit");
			choice=getValidate("Enter Your Choice");
			scanner.nextLine();
			switch(choice) {
			case 1:
				adminMenu();
				break;
			case 2:
				registerMemberMenu();
				break;
			case 3:
				lib.showAllbooks();
				break;
			case 4:
				borrowBookMenu();
				break;
			case 5:
				returnBookMenu();
				break;
			case 6:
				viewBorrowBooksMenu();
				break;
			case 7:
				System.out.println("Enter the Item Name to filter the data");
				String keyword=scanner.nextLine();
				lib.SearchBytitle(keyword);
				break;
			case 8:
				System.out.println("Enter the Author's Name to filter the data");
				String author=scanner.nextLine();
				lib.filterByauthor(author);
				break;
			case 9:
			     System.out.println("Exit");
			     break;
			default:
				System.out.println("Invalid Choice");
				
		}
		}while(choice!=9);
	}

	private static void viewBorrowBooksMenu() {
		System.out.println("Enter Member Id");
		int mid=scanner.nextInt();
		System.out.println("Enter Book Id");
		int bid=scanner.nextInt();
		Member m=lib.findMemberById(mid);
		Book b=lib.findBookByID(bid);
		
		if(m!=null && b!=null) {
			m.borrowedDeatails();
		}
		else {
			LoggerClass.error("Invalid Member or Book Id");
//			System.out.println("Invalid Member or Book Id");
		}
		
		
	}

	private static void returnBookMenu() {
		System.out.println("Enter Member Id");
		int mid=scanner.nextInt();
		System.out.println("Enter Book Id");
		int bid=scanner.nextInt();
		Member m=lib.findMemberById(mid);
		Book b=lib.findBookByID(bid);
		
		if(m!=null && b!=null) {
			m.returnBook(b);
		}
		else {
			LoggerClass.logger.error("Invalid Member or Book Id");
		}
		
		
	}
	
	public static int ch() {
		return 1;
	}

	private static void borrowBookMenu() {
		System.out.println("Enter Member Id");
		int mid=scanner.nextInt();
		System.out.println("Enter Book Id");
		int bid=scanner.nextInt();
		Member m=lib.findMemberById(mid);
		Book b=lib.findBookByID(bid);
		scanner.nextLine();
			System.out.println("Enter BorrowDate (yyyy-MM-dd)");
			String input=scanner.nextLine();
			LocalDate date=null;
			try {
				 date = LocalDate.parse(input);
			}catch(DateTimeParseException e) {
				System.out.println("Invalid Date Format");
			}
		if(m!=null && b!=null) {
			m.borrowBook(b,date);
		}
		else {
			LoggerClass.error("Invalid Member or Book Id");
//			System.out.println("Invalid Member or Book Id");
		}
		
	}
	
	
	


}
