module libraryManagement {
	requires log4j;
}